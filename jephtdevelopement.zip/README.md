# JephtDevelopement

Projet web de Jephte Manwana.

## Contenu
- index.html
- style.css

## Auteur
Jephte Manwana
